import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {

    public SeleniumTest() {
    }

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","driver/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://it.calcuworld.com/convertitori/convertitore-miglia-km/");
        driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[3]/table/tbody/tr[1]/td/form/input")).sendKeys("20");
        driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[3]/table/tbody/tr[1]/td/form/a")).click();
        WebElement m = driver.findElement(By.xpath("//*[@id=\"post-611\"]/div/div[3]/table/tbody/tr[2]/td/input"));
        System.out.println(m.getAttribute("value"));d
        driver.close();

    }
}
